# VoxCPM 聲線與粵語校音包

試音仍待聽校，並非正式書架音源。請開啟 voice-review/mei-school/README.md 查看原文與音檔；reports/cantonese/ 有字庫證據及逐語境查核表；assets/voice-references/ 是擷取的原聲參考。
